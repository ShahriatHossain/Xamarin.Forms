﻿using Xamarin.Forms;

namespace Tailoryfy.Views
{
    public partial class LoginVerifyPage : ContentPage
    {
        public LoginVerifyPage()
        {
            InitializeComponent();
        }
    }
}
