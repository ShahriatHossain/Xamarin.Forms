﻿using Xamarin.Forms;

namespace Tailoryfy.Views
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
