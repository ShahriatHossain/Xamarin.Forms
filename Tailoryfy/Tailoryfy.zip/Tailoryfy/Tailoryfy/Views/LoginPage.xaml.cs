﻿using Xamarin.Forms;

namespace Tailoryfy.Views
{
    public partial class LoginPage : ContentPage
    {
        public LoginPage()
        {
            InitializeComponent();
        }
    }
}
