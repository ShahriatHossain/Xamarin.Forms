﻿using Xamarin.Forms;

namespace Tailoryfy.Views
{
    public partial class ProductDetailsPage : ContentPage
    {
        public ProductDetailsPage()
        {
            InitializeComponent();
        }
    }
}
