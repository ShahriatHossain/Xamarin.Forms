﻿using Prism.Navigation;

namespace Tailoryfy.Core.Interfaces
{
    public interface IBaseInterface : INavigatedAware
    {
        void InitiatePageAsync();
        void SaveToSession();
    }
}
