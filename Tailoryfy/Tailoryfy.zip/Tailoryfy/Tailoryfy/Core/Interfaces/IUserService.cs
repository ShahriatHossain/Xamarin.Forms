﻿using Tailoryfy.Core.Models;
using System.Threading.Tasks;

namespace Tailoryfy.Core.Repositories
{
    public interface IUserService
    {
        Task<CustomResponse> VerifyLoginAsync(UserAccount user);
        Task<CustomResponse> UpdatePasswordAsync(UserAccount user);
    }
}
