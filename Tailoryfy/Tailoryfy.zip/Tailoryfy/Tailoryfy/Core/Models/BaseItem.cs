﻿//using SQLite;

//namespace Tailoryfy.Core.Models
//{
//    public class BaseItem
//    {
//        [PrimaryKey, AutoIncrement]
//        public int ID { get; set; }
//    }
//}
